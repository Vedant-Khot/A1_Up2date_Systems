"""Poll one IMAP mailbox and turn new messages into jobs."""

from __future__ import annotations

import asyncio
import email
import imaplib
import logging
import ssl
from email.header import decode_header
from email.utils import parseaddr

from app.store import store

log = logging.getLogger("sitelog.mail")
IMAP_TIMEOUT_SECONDS = 10


def _header(value: str) -> str:
    parts = []
    for text, encoding in decode_header(value or ""):
        if isinstance(text, bytes):
            parts.append(text.decode(encoding or "utf-8", errors="replace"))
        else:
            parts.append(text)
    return "".join(parts)


def _body(message: email.message.Message) -> str:
    if message.is_multipart():
        for part in message.walk():
            if part.get_content_type() == "text/plain" and "attachment" not in str(part.get("Content-Disposition") or ""):
                payload = part.get_payload(decode=True) or b""
                return payload.decode(part.get_content_charset() or "utf-8", errors="replace").strip()
        return ""
    payload = message.get_payload(decode=True) or b""
    if isinstance(payload, str):
        return payload.strip()
    return payload.decode(message.get_content_charset() or "utf-8", errors="replace").strip()


def readable_mail_error(exc: Exception) -> str:
    if isinstance(exc, TimeoutError):
        return "The mailbox did not respond in time."
    if isinstance(exc, ssl.SSLError):
        return "Could not start an SSL connection. Port 993 is the usual SSL port."
    if isinstance(exc, imaplib.IMAP4.error):
        text = str(exc).lower()
        if "auth" in text or "login" in text or "credential" in text or "invalid" in text:
            return "The mailbox rejected the email or password."
        return "The mailbox refused the connection."
    if isinstance(exc, OSError):
        return "Could not reach the IMAP host."
    return "The mailbox check failed."


def probe_mailbox(host: str, port: int, email_address: str, password: str) -> str:
    """Return an empty string when IMAP login works, otherwise a short error."""
    host = host.strip()
    email_address = email_address.strip()
    if not host or not email_address or not password:
        return "Host, email, and password are required."
    if port < 1 or port > 65535:
        return "Port must be between 1 and 65535. 993 is the usual SSL port."
    client = None
    try:
        client = imaplib.IMAP4_SSL(host, port, timeout=IMAP_TIMEOUT_SECONDS)
        client.login(email_address, password)
        return ""
    except Exception as exc:
        return readable_mail_error(exc)
    finally:
        if client is not None:
            try:
                client.logout()
            except Exception:
                pass


def poll_once() -> int:
    mailbox = store.mailbox_secret()
    if not mailbox or not mailbox["host"] or not mailbox["email"] or not mailbox["password"]:
        return 0
    created = 0
    error = ""
    client = None
    try:
        client = imaplib.IMAP4_SSL(mailbox["host"], int(mailbox["port"] or 993), timeout=IMAP_TIMEOUT_SECONDS)
        client.login(mailbox["email"], mailbox["password"])
        client.select("INBOX")
        status, data = client.search(None, "UNSEEN")
        if status != "OK" or not data or data[0] is None:
            error = "Could not read the inbox."
            return 0
        for number in data[0].split():
            fetched, payload = client.fetch(number, "(RFC822)")
            if fetched != "OK" or not payload or not isinstance(payload[0], tuple):
                continue
            message = email.message_from_bytes(payload[0][1])
            message_id = (message.get("Message-ID") or f"imap-{number.decode()}").strip()
            if store.email_seen(message_id):
                continue
            sender = parseaddr(_header(message.get("From") or ""))[1] or mailbox["email"]
            subject = _header(message.get("Subject") or "(no subject)")
            body = _body(message)[:8000]
            job = store.save_job(
                {
                    "work_ref": subject[:80] or "Email job",
                    "client": sender,
                    "site_address": "From email",
                    "issue": body[:500],
                    "email_from": sender,
                    "email_subject": subject,
                    "email_body": body,
                    "email_message_id": message_id,
                },
                None,
                source="email",
            )
            store.remember_email(message_id, job["id"])
            client.store(number, "+FLAGS", "\\Seen")
            created += 1
        return created
    except Exception as exc:
        error = readable_mail_error(exc)
        raise
    finally:
        if client is not None:
            try:
                client.logout()
            except Exception:
                pass
        store.record_mailbox_poll(created, error)


async def poll_loop() -> None:
    while True:
        try:
            count = await asyncio.to_thread(poll_once)
            if count:
                log.info("Saved %s jobs from email", count)
        except Exception as exc:
            log.warning("Mailbox poll failed: %s", exc)
        await asyncio.sleep(60)
